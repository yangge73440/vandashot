/**
 * Vandashot 品牌配置 —— 全项目唯一数据源
 * ============================================================
 * 想改名字、换成自己的链接、换默认搜索站点，只改这个文件。
 * 然后运行：
 *     npm run brand           # 仅重新注入品牌信息
 *     npm run build:store     # 注入 + 编译（推荐，prebuild 会自动注入）
 *
 * 注入脚本：scripts/apply-brand.mjs
 * 注意：请勿直接改 src/ 里由脚本生成的字段，下次构建会被覆盖。
 * ============================================================
 */

export const BRAND = {
  // ── 基本身份 ──────────────────────────────────────────────
  id: "vandashot",
  name: "Vandashot",
  version: "2.0.0",
  owner: "yangge73440",

  // 界面标语与扩展描述（中英各一份）
  tagline: {
    zh: "一次提问，并排对比多个 AI",
    en: "Ask once, compare every AI side by side",
  },
  description: {
    zh: "Vandashot 让搜索更快、更全面：同时调用多个 AI / 搜索站点，并排对比回答、导出整理。",
    en: "Vandashot makes search faster and more comprehensive by querying multiple AI/search sites side by side.",
  },

  // ── 对外链接 ──────────────────────────────────────────────
  // 留空字符串 = 该入口自动隐藏；social 留空数组 = 不渲染社媒区
  links: {
    website: "",
    repository: "https://github.com/yangge73440/Vandashot",
    profile: "https://github.com/yangge73440",
    docs: "https://github.com/yangge73440/Vandashot#readme",
    social: [
      // 想加自己的账号就往这里填，例如：
      // { label: "B站", url: "https://space.bilibili.com/你的UID", icon: "bilibili" },
    ],
  },

  // ── 首次安装写入的默认自定义站点 ──────────────────────────
  // 设为 null 则完全不预置任何自定义站点
  defaultCustomSite: {
    name: "GitHub 搜索",
    url: "https://github.com/search?q={query}",
    matchPatterns: ["github.com"],
  },

  // ── 上游项目致谢（GPL-3.0 要求保留，请勿删除） ────────────
  upstream: {
    name: "Qshot · 子弹搜索",
    author: "30bewater",
    repository: "https://github.com/30bewater/Qshot",
    license: "GPL-3.0",
    modifiedOn: "2026-11-07",
  },
};

export default BRAND;
