/**
 * Vandashot 品牌注入脚本
 * ============================================================
 * 读取根目录 brand.config.mjs，把品牌信息写入所有"可见文本 / 外部链接 /
 * 首次安装预设 / 图标 / 法律文档"的落点。
 *
 * 设计原则：
 *  1. 幂等 —— 所有替换都基于"结构特征"而非旧值，重复运行结果一致；
 *  2. 不碰内部标识 —— CSS 类名 qshot-*、协议常量 QSHOT_*、全局变量
 *     __QSHOT_* 属于代码内部标识，改动会破坏功能，且用户不可见；
 *  3. 单一数据源 —— 改 brand.config.mjs 后跑 `npm run brand` 即可全局生效。
 *
 * 由 package.json 的 prebuild / prebuild:store 钩子自动调用。
 */
import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { BRAND } from "../brand.config.mjs";
import { makeIcons } from "./make-icons.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const changed = [];

function abs(rel) {
  return path.join(ROOT, rel);
}

async function read(rel) {
  return readFile(abs(rel), "utf8");
}

async function write(rel, content) {
  await mkdir(path.dirname(abs(rel)), { recursive: true });
  const before = (await readFile(abs(rel), "utf8").catch(() => null));
  if (before === content) return;
  await writeFile(abs(rel), content, "utf8");
  changed.push(rel);
}

function sub(text, pattern, replacement, label) {
  const re = new RegExp(pattern.source, pattern.flags.replace("g", ""));
  if (!re.test(text)) {
    throw new Error(`[brand] 未匹配到「${label}」，请检查源码结构是否变动`);
  }
  return text.replace(pattern, replacement);
}

async function editJson(rel, mutator, _label) {
  const data = JSON.parse(await read(rel));
  mutator(data);
  await write(rel, JSON.stringify(data, null, 2) + "\n");
}

// ── 1. 运行时品牌模块（前端 import 这个，改配置即生效） ──────────
async function generateBrandModule() {
  const content = `// 自动生成，请勿手动编辑 —— 改根目录 brand.config.mjs 后运行 npm run brand
export const BRAND = ${JSON.stringify(BRAND, null, 2)};

if (typeof globalThis !== "undefined") {
  globalThis.__VANDASHOT_BRAND__ = BRAND;
}

export default BRAND;
`;
  await write("src/config/brand.generated.js", content);
}

// ── 2. 扩展名 / 描述 / 版本 ─────────────────────────────────────
async function patchLocales() {
  await write(
    "src/_locales/zh_CN/messages.json",
    JSON.stringify(
      {
        extensionName: { message: `${BRAND.name} · ${BRAND.tagline.zh}` },
        extensionDescription: { message: BRAND.description.zh },
      },
      null,
      2
    ) + "\n"
  );
  await write(
    "src/_locales/en/messages.json",
    JSON.stringify(
      {
        extensionName: { message: `${BRAND.name} - ${BRAND.tagline.en}` },
        extensionDescription: { message: BRAND.description.en },
      },
      null,
      2
    ) + "\n"
  );
}

async function patchManifestAndPackage() {
  await editJson(
    "src/manifest.json",
    (m) => {
      delete m.default_title; // 清理早期误写到顶层的字段
      if (!m.action) m.action = {};
      m.action.default_title = BRAND.name; // Chrome 实际读取的是 action.default_title
      m.version = BRAND.version;
    },
    "action.default_title / version"
  );
  await editJson(
    "package.json",
    (p) => {
      p.name = BRAND.id;
      p.version = BRAND.version;
      p.description = BRAND.description.zh;
    },
    "name / version / description"
  );
  // lockfile 的顶层与 packages[""] 也要同步，否则 npm 会报名称不一致
  await editJson(
    "package-lock.json",
    (lock) => {
      lock.name = BRAND.id;
      lock.version = BRAND.version;
      if (lock.packages && lock.packages[""]) {
        lock.packages[""].name = BRAND.id;
        lock.packages[""].version = BRAND.version;
      }
    },
    "lockfile name / version"
  );
}

// ── 3. 首次安装写入的默认自定义站点 ────────────────────────────
async function patchInitialStates() {
  const site = BRAND.defaultCustomSite;
  const list = site
    ? [
        {
          id: "custom_vandashot_default",
          name: site.name,
          url: site.url,
          enabled: true,
          supportIframe: true,
          supportUrlQuery: true,
          matchPatterns: site.matchPatterns,
          isCustom: true,
          customType: "url",
        },
      ]
    : [];

  for (const rel of [
    "src/config/initialState.json",
    "src/config/initialState.zh-CN.json",
    "src/config/initialState.en.json",
  ]) {
    await editJson(rel, (d) => { d.customSites = list; }, "customSites");
  }
}

// ── 4. 源码中的可见文本 ────────────────────────────────────────
async function patchVisibleText() {
  // 基础配置里的应用名
  {
    const rel = "src/config/baseConfig.js";
    let t = await read(rel);
    t = sub(t, /(appName:\s*")[^"]*(")/, `$1${BRAND.name} · ${BRAND.tagline.zh}$2`, "baseConfig.appName");
    await write(rel, t);
  }

  // 右键菜单根标题
  {
    const rel = "src/background/context-menu.js";
    let t = await read(rel);
    t = sub(
      t,
      /(\btitle:\s*")[^"]*(搜索|\\u641c)[^"]*(")/,
      `$1${BRAND.name} 搜索$3`,
      "context-menu 根标题"
    );
    await write(rel, t);
  }

  // i18n 文案里的品牌字面量（大小写敏感，不会碰到 __QSHOT_I18N__ / qshot-* 类名）
  {
    const rel = "src/shared/i18n.js";
    let t = await read(rel);
    t = t.replace(/\bQshot\b/g, BRAND.name);
    await write(rel, t);
  }

  // 诊断日志前缀
  {
    const rel = "src/shared/diagnostics.js";
    let t = await read(rel);
    t = sub(
      t,
      /(const LOG_PREFIX = "\[)[^\]]*(\]";)/,
      `$1${BRAND.name} diagnostics$2`,
      "diagnostics LOG_PREFIX"
    );
    await write(rel, t);
  }
}

// ── 4b. 散落在业务代码里的可见文案 / tooltip / 注释 ─────────────
async function patchResidualText() {
  const files = [
    "src/background/main.js",
    "src/iframe/inject/input-prompt-launcher.js",
    "src/iframe/overlay/overlay-mount.js",
    "src/settings/settings/sections/prompts-ai-launcher-setting.js",
    "src/iframe/inject/sidebar-fix.js",
    "src/iframe/iframe/ai-summary-stream-logo.js",
    "src/iframe/styles/06-ai-summary.css",
  ];
  for (const rel of files) {
    const t = await read(rel);
    await write(rel, t.replace(/\bQshot\b/g, BRAND.name));
  }
}

// ── 5. HTML 中的标题 / alt / 占位符 / 外链 ─────────────────────
async function patchHtml() {
  const docsUrl = BRAND.links.docs || "#";

  {
    const rel = "src/popup/popup.html";
    let t = await read(rel);
    t = sub(t, /(<title>)[^<]*(<\/title>)/, `$1${BRAND.name}$2`, "popup title");
    t = sub(t, /(alt=")[^"]*(" class="popup-title-logo")/, `$1${BRAND.name}$2`, "popup logo alt");
    await write(rel, t);
  }

  {
    const rel = "src/iframe/iframe.html";
    let t = await read(rel);
    t = sub(
      t,
      /(<title data-i18n="iframe_pageTitle">)[^<]*(<\/title>)/,
      `$1${BRAND.name} · ${BRAND.tagline.zh}$2`,
      "iframe title"
    );
    t = sub(t, /(placeholder=")[^"]*( 一下")/, `$1${BRAND.name}$2`, "iframe 输入占位符");
    await write(rel, t);
  }

  {
    const rel = "src/settings/settings.html";
    let t = await read(rel);
    t = sub(t, /(alt=")[^"]*(" class="settings-logo-image")/, `$1${BRAND.name}$2`, "settings logo alt");
    t = sub(
      t,
      /(<a id="promptLearnLink"[^>]*?href=")[^"]*(")/,
      `$1${docsUrl}$2`,
      "promptLearnLink href"
    );
    await write(rel, t);
  }
}

// ── 6. 关于页（完全由品牌配置驱动） ────────────────────────────
async function generateAboutSection() {
  const links = BRAND.links;
  const social = Array.isArray(links.social) ? links.social : [];

  const buttons = [];
  if (links.website) buttons.push({ label: "项目官网", url: links.website });
  if (links.repository) buttons.push({ label: "项目仓库", url: links.repository });
  if (links.profile) buttons.push({ label: "开发者主页", url: links.profile });
  buttons.push({ label: "上游项目", url: BRAND.upstream.repository });

  const buttonsHtml = buttons
    .map(
      (b) =>
        `      <a class="about-plugin-action-btn" href="${b.url}" target="_blank" rel="noreferrer noopener">${b.label}</a>`
    )
    .join("\n");

  const socialHtml = social.length
    ? `
      <div class="about-plugin-action-btn about-plugin-action-btn--author" role="group" aria-label="开发者账号">
        <span class="about-plugin-author-label">开发者：${BRAND.owner}</span>
        <div class="about-plugin-author-links">
${social
  .map(
    (s) =>
      `          <a class="about-plugin-social" href="${s.url}" target="_blank" rel="noreferrer noopener">${s.label}</a>`
  )
  .join("\n")}
        </div>
      </div>`
    : "";

  const content = `// 自动生成，请勿手动编辑 —— 改根目录 brand.config.mjs 后运行 npm run brand
import { state, msg } from "../state.js";
import { BRAND } from "../../../config/brand.generated.js";

export function renderAboutSection() {
  const { aboutSection } = state.dom;
  aboutSection.innerHTML = "";

  const privacyCard = document.createElement("section");
  privacyCard.className = "other-settings-card about-plugin-card";
  privacyCard.innerHTML = \`
    <div class="other-settings-intro about-plugin-intro">
      <strong>\${msg("settings_about_privacyTitle", "隐私与数据说明")}</strong>
    </div>
    <div class="about-plugin-privacy" role="note">
      <p><strong>\${msg("settings_about_openSourceLabel", "开源且免费：")}</strong>\${msg("settings_about_openSourceBody", "${BRAND.name} 是一个开源且免费插件，不会运行任何后端服务器。")}</p>
      <p><strong>\${msg("settings_about_zeroDataLabel", "零数据收集：")}</strong>\${msg("settings_about_zeroDataBody", "${BRAND.name} 不会将您的搜索关键词、浏览记录或页面内容上传到开发者服务器。用于功能的配置数据仅保存在本地。")}</p>
      <p><strong>\${msg("settings_about_transparencyLabel", "交互透明性：")}</strong>\${msg("settings_about_transparencyBody", "插件通过 iframe 或新标签页模式打开目标网站，您与网站的登录与交互均直接发生在浏览器与目标网站之间。")}</p>
      <p><strong>基于开源项目：</strong>本作品基于 \${BRAND.upstream.name}（\${BRAND.upstream.author}，\${BRAND.upstream.license}）修改，保留原作者版权声明。</p>
    </div>
  \`;
  aboutSection.appendChild(privacyCard);

  const linksRow = document.createElement("div");
  linksRow.className = "about-plugin-links-wrap";
  linksRow.innerHTML = \`
    <div class="about-plugin-actions" aria-label="相关链接">
${buttonsHtml}${socialHtml}
    </div>
  \`;
  aboutSection.appendChild(linksRow);
}
`;
  await write("src/settings/settings/sections/about.js", content);
}

// ── 7. 设置页「学习提示词」外链：docs 为空时自动隐藏 ───────────
async function patchSettingsMain() {
  const rel = "src/settings/settings/main.js";
  let t = await read(rel);

  if (!t.includes("brand.generated.js")) {
    t = sub(
      t,
      /(import \{ loadBuiltinSites \} from "\.\/utils\.js";)/,
      `$1\nimport { BRAND } from "../../config/brand.generated.js";`,
      "settings/main.js import"
    );
  }

  const block = `  if (dom.promptLearnLink) {
    const docsUrl = BRAND.links?.docs || "";
    dom.promptLearnLink.hidden = !showPrompts || !docsUrl;
    if (docsUrl) dom.promptLearnLink.href = docsUrl;
  }`;

  t = sub(
    t,
    /  if \(dom\.promptLearnLink\) \{[\s\S]*?\n  \}/,
    block,
    "promptLearnLink 显示逻辑"
  );
  await write(rel, t);
}

// ── 8. 文字标 ────────────────────────────────────────────────
function makeWordmark(rel, width, height) {
  const box = Math.min(width, height) * 0.78;
  const x0 = 0;
  const y0 = (height - box) / 2;
  const textX = box + width * 0.035;
  const avail = width - textX;
  const fontSize = Math.min(height * 0.42, (avail / (BRAND.name.length * 0.58)));
  const baseline = height / 2 + fontSize * 0.35;
  const stroke = box * 0.1;

  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${BRAND.name}">
  <rect x="${x0}" y="${y0}" width="${box}" height="${box}" rx="${box * 0.22}" fill="#185FA5"/>
  <path d="M ${x0 + box * 0.28} ${y0 + box * 0.27} L ${x0 + box * 0.5} ${y0 + box * 0.74} L ${x0 + box * 0.72} ${y0 + box * 0.27}" stroke="#FFFFFF" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  <text x="${textX}" y="${baseline}" font-family="system-ui, -apple-system, 'Segoe UI', 'Microsoft YaHei', sans-serif" font-size="${fontSize.toFixed(1)}" font-weight="600" fill="currentColor">${BRAND.name}</text>
</svg>
`;
}

async function generateWordmarks() {
  const specs = [
    ["src/settings/about-logo.svg", 386, 128],
    ["src/popup/logo.svg", 200, 56],
  ];
  for (const [rel, w, h] of specs) {
    const original = await read(rel).catch(() => "");
    const wMatch = original.match(/width="(\d+)"/);
    const hMatch = original.match(/height="(\d+)"/);
    const width = wMatch ? Number(wMatch[1]) : w;
    const height = hMatch ? Number(hMatch[1]) : h;
    await write(rel, makeWordmark(rel, width, height));
  }
}

// ── 9. 法律文档 ──────────────────────────────────────────────
async function generateLegalDocs() {
  const notice = `# NOTICE — 修改与版权声明

**${BRAND.name}** ${BRAND.version}
维护者：${BRAND.owner}
修改日期：${BRAND.upstream.modifiedOn}

## 上游项目

本作品衍生自 **${BRAND.upstream.name}**
原作者：${BRAND.upstream.author}
上游仓库：${BRAND.upstream.repository}
上游协议：**${BRAND.upstream.license}**

## 本版本做了什么

- 将产品名称、界面文案、扩展标识、图标全部更换为 **${BRAND.name}**；
- 将首次安装的默认自定义站点、关于页外链、开发者信息改为本版本维护者信息；
- 新增 \`brand.config.mjs\` 品牌单一数据源与 \`scripts/apply-brand.mjs\` 注入脚本；
- 重写项目文档与隐私政策，补充本 NOTICE。

## 授权条款（GPL-3.0 要求）

1. 本作品继续以 **GNU General Public License v3.0** 授权，完整条款见 \`LICENSE\`；
2. 上游作者的版权声明与 \`LICENSE\` 原文予以保留，未作删除或替换；
3. 本文件即为 GPL-3.0 第 5(a) 条所要求的「修改声明」；
4. 若你再分发本作品（含编译后的 \`dist/\`），必须同时提供对应源代码，
   并继续以 GPL-3.0 授权，不得附加额外限制。

> 你可以自由地修改、使用、分发本作品用于学习与个人用途；
> 但不得声称上游代码为你原创，也不得移除上述版权与协议信息。
`;
  await write("NOTICE.md", notice);

  const privacy = `# ${BRAND.name} 隐私政策

**适用版本**：${BRAND.name} ${BRAND.version} 及以上
**维护者**：${BRAND.owner}
**项目仓库**：${BRAND.links.repository || "（未设置）"}
**上游项目**：${BRAND.upstream.name}（${BRAND.upstream.repository}）

> 本政策由上游 ${BRAND.upstream.name} 隐私政策改编，适用于本修改版。
> 上游原作者不对本修改版的行为负责。

## 一句话说明

${BRAND.name} 是一个**纯本地运行**的浏览器扩展。它没有后端服务器，
不收集、不上传你的搜索关键词、浏览记录、页面内容或账号信息。

## 数据存在哪里

| 数据 | 存储位置 | 是否外传 |
|---|---|---|
| 搜索组、自定义站点、提示词库 | \`chrome.storage.local\`（本机浏览器） | 否 |
| 搜索历史（默认关闭） | \`chrome.storage.local\` | 否 |
| 布局、主题、快捷键等偏好 | \`chrome.storage.local\` | 否 |
| AI 总结用的 API Key | \`chrome.storage.local\`，密码框输入 | 仅发送给你自己选择的服务商 |
| 导出的 JSON / Markdown | 由你主动下载到本机 | 否 |

## 网络请求会发到哪里

1. **你选择的 AI / 搜索站点** —— 由浏览器直连，使用你自己的登录会话；
2. **你配置的 AI 总结服务商** —— 仅在启用该功能、填入自己的 API Key 后，
   由浏览器直连该服务商的 \`/chat/completions\` 接口；
3. **同源导出** —— 导出 ChatGPT 对话时读取其 \`/backend-api/conversation/*\`，
   请求发往 chatgpt.com 自身；
4. **站点预热（可关闭）** —— 默认每 5 分钟向已启用的 AI 站点发一次
   \`no-cors\` 请求以缩短首次加载时间，会复用你的登录 Cookie，但不读取响应内容。
   可在设置中关闭「预加载 / prewarm」。

**不会**向维护者或任何第三方统计服务器发送数据。

## 权限说明

| 权限 | 用途 |
|---|---|
| \`storage\` | 本地保存配置 |
| \`activeTab\` / \`tabs\` / \`windows\` | 打开对比页、站点标签页与弹窗 |
| \`contextMenus\` | 选中文字后的右键搜索入口 |
| \`alarms\` | 站点预热定时 |
| \`declarativeNetRequest\` | 调整第三方站点的 CSP / X-Frame-Options 等响应头，使其能嵌入对比页卡片 |
| \`host_permissions: <all_urls>\` | 在你访问的页面注入浮层、定位输入框、提取导出内容，并支持自定义站点 |
| \`downloads\` | 导出文件（当前商店构建版未启用） |

扩展的 Content Security Policy 限定 \`script-src 'self'\`，
**不会加载任何远程脚本**，也不包含第三方分析、广告或追踪 SDK。

## 关于 AI 总结

该功能默认关闭，需要你自行填写 API Key。密钥仅保存在本机，
只会出现在发往你所选择服务商的 \`Authorization\` 请求头中。
请勿分享含有密钥的导出 JSON。

## 修改与联系

本版本基于 GPL-3.0 项目修改，详见 \`NOTICE.md\`。
问题与建议请提交至：${BRAND.links.repository || BRAND.links.profile || "项目仓库"}
`;
  await write("PRIVACY.md", privacy);
}

// ── 10. 残留审计 ─────────────────────────────────────────────
async function audit() {
  const { readdir } = await import("node:fs/promises");
  const skip = new Set(["brand.generated.js"]);
  const found = [];
  // 注意：上游仓库地址 github.com/30bewater/Qshot 属于 GPL 要求的署名致谢，
  // 允许且应当出现在 about.js / NOTICE.md 中，因此不计入残留。
  const forbidden = /30aitool|space\.bilibili|douyin\.com\/user|xiaohongshu\.com\/user|feishu\.cn|qshot\.top/;

  async function walk(dir) {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (["node_modules", "dist", ".git"].includes(entry.name)) continue;
        await walk(p);
      } else if (/\.(js|mjs|json|html|svg|md|css)$/.test(entry.name) && !skip.has(entry.name)) {
        const text = await readFile(p, "utf8").catch(() => "");
        for (const [i, line] of text.split("\n").entries()) {
          if (forbidden.test(line)) {
            found.push(`${path.relative(ROOT, p)}:${i + 1}  ${line.trim().slice(0, 120)}`);
          }
        }
      }
    }
  }

  await walk(path.join(ROOT, "src"));
  return found;
}

// ── 主流程 ───────────────────────────────────────────────────
export async function applyBrand({ icons = true } = {}) {
  await generateBrandModule();
  await patchLocales();
  await patchManifestAndPackage();
  await patchInitialStates();
  await patchVisibleText();
  await patchResidualText();
  await patchHtml();
  await generateAboutSection();
  await patchSettingsMain();
  await generateWordmarks();
  if (icons) await makeIcons();
  await generateLegalDocs();

  const leftovers = await audit();
  return { changed: [...new Set(changed)], leftovers };
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  applyBrand()
    .then(({ changed, leftovers }) => {
      console.log(`[brand] ${BRAND.name} v${BRAND.version} · 已更新 ${changed.length} 处：`);
      for (const c of changed) console.log(`  - ${c}`);
      if (leftovers.length) {
        console.log(`\n[brand] ⚠ 以下位置仍含上游作者链接（请确认是否为合规致谢）：`);
        for (const l of leftovers) console.log(`  ${l}`);
      } else {
        console.log(`\n[brand] ✓ src/ 中已无上游作者私有链接残留`);
      }
    })
    .catch((err) => {
      console.error(err.message || err);
      process.exit(1);
    });
}
