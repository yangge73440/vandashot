/**
 * 生成 Vandashot 扩展图标（零外部依赖，纯 Node 手写 PNG）。
 * 由 apply-brand.mjs 调用；也可单独运行 `node scripts/make-icons.mjs`。
 */
import { writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { deflateSync } from "node:zlib";
import { BRAND } from "../brand.config.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const ICON_DIR = path.join(ROOT, "src", "icons");
const SIZES = [16, 32, 48, 128];
const BG = [24, 95, 165, 255]; // #185FA5
const FG = [255, 255, 255, 255];

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, "ascii"), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
}

// 点到线段距离（归一化坐标）
function segmentDistance(px, py, ax, ay, bx, by) {
  const dx = bx - ax;
  const dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

function coverage(x, y, size, samples = 3) {
  let hit = 0;
  for (let sy = 0; sy < samples; sy++) {
    for (let sx = 0; sx < samples; sx++) {
      const px = (x + (sx + 0.5) / samples) / size;
      const py = (y + (sy + 0.5) / samples) / size;
      const d = Math.min(
        segmentDistance(px, py, 0.27, 0.26, 0.5, 0.75),
        segmentDistance(px, py, 0.73, 0.26, 0.5, 0.75)
      );
      if (d < 0.085) hit++;
    }
  }
  return hit / (samples * samples);
}

function roundedRectAlpha(x, y, size) {
  const r = 0.2;
  const half = 0.45;
  const dx = Math.abs(x - 0.5);
  const dy = Math.abs(y - 0.5);
  if (dx <= half - r || dy <= half - r) return 1;
  const cx = half - r;
  const cy = half - r;
  const dist = Math.hypot(Math.max(0, dx - cx), Math.max(0, dy - cy));
  return Math.max(0, Math.min(1, (r - dist) * size));
}

function makePng(size) {
  const raw = Buffer.alloc(size * (1 + size * 4));
  for (let y = 0; y < size; y++) {
    const rowStart = y * (1 + size * 4);
    raw[rowStart] = 0; // filter: none
    for (let x = 0; x < size; x++) {
      const nx = (x + 0.5) / size;
      const ny = (y + 0.5) / size;
      const bgA = roundedRectAlpha(nx, ny, size);
      const fgA = coverage(x, y, size) * bgA;
      const o = rowStart + 1 + x * 4;
      for (let c = 0; c < 4; c++) {
        raw[o + c] = Math.round(BG[c] * (1 - fgA) + FG[c] * fgA);
      }
      raw[o + 3] = Math.round(255 * bgA);
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

export async function makeIcons() {
  await mkdir(ICON_DIR, { recursive: true });
  for (const size of SIZES) {
    await writeFile(path.join(ICON_DIR, `icon${size}.png`), makePng(size));
  }
  return SIZES.map((s) => `icon${s}.png`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  makeIcons().then((files) => {
    console.log(`[brand] icons regenerated for ${BRAND.name}: ${files.join(", ")}`);
  });
}
