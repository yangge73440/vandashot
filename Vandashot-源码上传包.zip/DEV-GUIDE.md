# Vandashot 二次开发指南

面向想在这个版本上继续改的人。假设你已能跑通 `npm run build:store`。

---

## 1. 命令速查

| 命令 | 作用 |
|---|---|
| `npm run brand` | 只重新注入品牌信息（幂等，无变化时输出「已更新 0 处」） |
| `npm run build:store` | **推荐**：自动注入品牌 → 编译商店版到 `dist/` |
| `npm run watch:store` | 监听 `src/` 变化持续构建 |
| `NODE_ENV=production npm run build:store` | 生产构建（压缩、无 sourcemap） |
| `node scripts/make-icons.mjs` | 单独重生成四档 PNG 图标 |

`prebuild` / `prebuild:store` / `prewatch*` 钩子会自动调用 `npm run brand`，
所以**改完 `brand.config.mjs` 直接 build 就行**，不用手动跑 brand。

---

## 2. 改品牌信息

唯一入口：根目录 `brand.config.mjs`。

| 字段 | 影响范围 |
|---|---|
| `name` | 扩展名、弹窗/对比页标题、右键菜单、logo alt、tooltip、日志前缀、所有界面文案 |
| `version` | `manifest.json`、`package.json`、NOTICE |
| `owner` | 关于页「开发者」标识 |
| `tagline.zh` / `.en` | 扩展副标题、对比页标题、输入框占位符 |
| `description.zh` / `.en` | Chrome 扩展管理页显示的描述 |
| `links.website` | 关于页「项目官网」按钮；**留空则不显示** |
| `links.repository` / `profile` | 关于页按钮、隐私政策里的联系地址 |
| `links.docs` | 设置页「学习提示词」外链；**留空则该链接自动隐藏** |
| `links.social` | 关于页社交账号区；`[]` = 整块不渲染。格式 `{ label, url }` |
| `defaultCustomSite` | 首次安装写入的自定义站点；设为 `null` 则完全不预置 |
| `upstream` | **GPL 致谢信息，请勿删除**（见第 9 节） |

注入脚本 `scripts/apply-brand.mjs` 采用「结构特征匹配」而非「替换旧值」，
因此重复运行安全。它**刻意不改**以下内部标识，因为它们用户不可见、改了会破坏功能：

- CSS 类名前缀 `qshot-*`
- 全局协议常量 `__QSHOT_*` / `QSHOT_*`
- 内部变量名 `qshotLastWarmupAt` 等

如果你要新增一处品牌文案，优先把值放进 `brand.config.mjs`，
再到 `scripts/apply-brand.mjs` 加一条 `sub(...)` 规则，而不是直接写死在 `src/` 里。

---

## 3. 增删 / 修复 AI 站点

核心文件：`src/config/siteHandlers.json`（约 65 KB，29 个站点）。

每个站点的关键字段：

```jsonc
{
  "id": "deepseek",                    // 唯一 ID，被搜索分组引用
  "name": "DeepSeek",
  "url": "https://chat.deepseek.com/",
  "enabled": true,
  "supportIframe": true,               // false = 用新标签页打开
  "supportUrlQuery": false,            // true = URL 里可带 {query} 模板
  "matchPatterns": ["chat.deepseek.com"],
  "searchHandler": {
    "submitVerifyWaitMs": 1600,
    "steps": [                         // 注入脚本按顺序执行的 DOM 动作
      { "action": "focus", "selectors": ["textarea", "div[contenteditable='true']"] },
      { "action": "setValue", "..." : "..." },
      { "action": "click",  "..." : "..." }
    ]
  }
}
```

**网站改版导致卡片发不出去时**，改的就是 `steps` 里的 CSS 选择器和等待时间。
执行逻辑在 `src/iframe/inject/executor*.js` 与 `executor-actions.js`。

新增站点还要同步三处：
1. `src/config/siteHandlers.json` 加一条；
2. `src/manifest.json` 的 `content_scripts[].matches` 加域名（否则注入脚本不生效）；
3. `src/config/rules-source.mjs` 的 `HOST_RULES` 加 host（否则被 CSP / X-Frame-Options 挡住）。

`rules-source.mjs` 改完由 `build.mjs` 在构建时展开成 `dist/config/rules.json`，
当前共 58 条规则（57 个 host + 1 条批量规则）。

---

## 4. 改首次安装的默认预设

三份文件需保持一致：`src/config/initialState.json`、
`initialState.zh-CN.json`、`initialState.en.json`。

| 顶层键 | 内容 |
|---|---|
| `searchGroups` | 搜索分组，元素含 `name` 与 `siteIds`（引用站点 id） |
| `promptGroups` | 提示词组，16 条内置 prompt 都在这里 |
| `selectionContextGroups` | 划词搜索的站点分组（默认「翻译」→ DeepSeek） |
| `customSites` | **由 brand 脚本覆盖**，想改请改 `brand.config.mjs` |
| `quickAccessSites` | 快捷站点 id 数组 |
| `aiSummarySettings` | AI 总结服务商、模型名、空 API Key |
| `uiPrefs` | 界面偏好（见第 7 节） |

> 注意：`customSites` 每次 `npm run brand` 都会被重写。
> 想保留自己手改的默认站点，请把它写进 `brand.config.mjs` 的 `defaultCustomSite`。

`src/config/random-questions/{zh-CN,en}.txt` 是「随机提问」按钮的题库，每行一条，直接编辑即可。

---

## 5. 架构速览

```
build.mjs
  ├─ esbuild 打包 12 个入口 → dist/*.js（IIFE，bundle）
  ├─ copyAssets()           → manifest / html / css / json / 图标
  ├─ patchManifest()        → 按 feature flag 增删权限与注入块
  └─ generateRules()        → rules-source.mjs → dist/config/rules.json
```

运行时三层：

| 目录 | 运行位置 | 职责 |
|---|---|---|
| `src/background/` | Service Worker | 右键菜单、快捷键、标签页、预热、初始状态写入 |
| `src/iframe/iframe/` | 扩展自己的对比页 | 卡片渲染、布局、发送调度、导出、AI 总结 |
| `src/iframe/inject/` | 注入到第三方 AI 页面 | 定位输入框、填入并提交、抽取对话内容 |
| `src/iframe/overlay/` | 注入到任意网页 | Ctrl+Q 浮层、Shadow DOM 样式隔离 |
| `src/popup/`、`src/settings/` | 扩展页面 | 弹窗与设置页 |

`src/shared/` 放 i18n、AI 服务商定义、存储键、诊断日志等共用模块。

---

## 6. 三个必须知道的坑

**① 改 content script 后要重开标签页**
改 `background/`、`popup/`、`settings/`、`iframe/` 里的扩展页面，
在 `chrome://extensions/` 点「刷新」即可；
但改了 `inject/` 或 `overlay/`（content script），还必须**关闭并重开目标网页**。

**② 部分站点禁止 iframe**
这是对方的安全策略，不是 bug。`siteHandlers.json` 里 `supportIframe: false` 的站点
（当前是 MIMo、Perplexity）会退化成新标签页模式。
上游靠 `iframe-anti-detect.js`（以 `world: "MAIN"` 注入）和 DNR 改响应头来绕过，
网站一改版就可能失效，属长期维护项。

**③ `npm run build`（不带 `:store`）会报错**
`src/config/features-source.mjs` 定义了 `memory` 与 `desktop` 两个实验功能开关，
默认构建会打开它们并尝试编译 `memory/content.js`、`memory/background.js`、
`desktop/background.js`、`sections/memory.js` —— 这些文件在上游公开仓库里
被 `.gitignore` 排除了，因此 esbuild 报 4 个 `Could not resolve` 错误。

`--features=store` 会关掉这两个功能，并把 `downloads` 权限与 memory 注入块一并移除。
**日常开发只用 `build:store` / `watch:store`。**

---

## 7. 三项「本版本保留原样」的可选优化

这些是审计中发现的、但按维护者要求**没有改动**的点。想做的话位置都在这里：

### 7.1 关闭默认后台预热
`src/config/initialState*.json` → `uiPrefs.prewarmEnabled: true` 改为 `false`。

`src/background/warmup.js` 每 5 分钟会对所有启用的 AI 站点发一次
`fetch(url, { credentials: "include", mode: "no-cors" })`，
即使用户没在用插件也会带着登录 Cookie 访问。目的是缩短首次加载时间，
`no-cors` 不读响应体，但请求本身仍会发出。

> 三份 initialState 都要改；brand 脚本不会碰 `uiPrefs`。

### 7.2 清除实验模块残留
- 删除 `src/manifest.json` 中 `content_scripts` 里引用 `memory/content.js` 的那一块；
- 精简 `src/config/features-source.mjs`（或直接让 `DEFAULT_FEATURE_KEYS = []`）；
- 同步清理 `build.mjs` 里的 `collectEntries` / `patchManifest` / `makeFeatureDefines` 相关分支。

做完后 `npm run build` 与 `build:store` 都能正常编译，
manifest 也不会再申请 `nativeMessaging` 权限（当前仅默认构建会加）。

### 7.3 收紧权限
- `src/manifest.json`：`host_permissions: <all_urls>` 是最大权限面，
  可按实际使用的站点列表收窄；但会**影响自定义站点功能**；
- `content_scripts` 里 5 个 `<all_urls>` 块同理；
- `src/config/rules-source.mjs`：目前对包含 `accounts.google.com` 在内的 57 个 host
  移除 CSP / X-Frame-Options / COOP 等头，可删掉不需要的域名；
- `src/iframe/iframe-anti-detect.js` 与 `overlay_main.js` 的 `world: "MAIN"` 注入
  会改写页面的 `window.top` / `parent` / `frameElement`，
  是「多站并排」能工作的前提，删除前请确认可接受的降级范围。

> 建议逐项改动、每次重新构建并在真实站点上验证，不要一次性全关。

---

## 8. 调试

- 设置页里把 `uiPrefs.diagnosticLogsEnabled` 打开，日志前缀 `[Vandashot diagnostics]`；
  日志只 `console.log`，且 `diagnostics.js` 会对 query / prompt / url 做脱敏；
- 对比页、弹窗、设置页各有独立的 DevTools（在对应页面按 F12）；
- 注入到第三方页面的脚本，要在**那个页面**的 DevTools 里看；
- 构建产物默认是 dev 模式（带 inline sourcemap、不压缩），便于定位。

---

## 9. 合规提醒（GPL-3.0）

- `LICENSE` 是 GPL-3.0 原文，**不要删除或替换**；
- `NOTICE.md` 由 brand 脚本生成，会随 `dist/` 一起分发（`build.mjs` 的 `ROOT_ASSETS`）；
- `brand.config.mjs` 的 `upstream` 段与关于页的「上游项目」链接属于署名，请保留；
- 若你把编译后的 `dist/` 发给别人，需同时提供对应源码并继续以 GPL-3.0 授权；
- 可以改名字、改功能、商用，但不能声称上游代码是你原创，也不能改成闭源。
