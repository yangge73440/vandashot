﻿<div align="center">

# Vandashot

**一次提问，并排对比多个 AI**

Chrome / Edge Manifest V3 扩展 · 纯本地运行 · 无后端 · GPL-3.0

</div>

---

## 这是什么

Vandashot 把同一个问题**一次性发送给多个 AI / 搜索站点**，在同一个对比页里并排展示各家回答，
省掉在 ChatGPT、DeepSeek、Kimi、Gemini 之间来回切标签页、反复复制粘贴的功夫。

支持 Ctrl+Q 全局浮层、搜索分组、提示词库、划词/右键搜索、历史记录、Markdown 导出、
可选的 AI 一键总结，以及暗色模式。**所有配置只存在你自己的浏览器里**。

## 与上游项目的关系

本作品衍生自 [**Qshot · 子弹搜索**](https://github.com/30bewater/Qshot)（作者 30bewater，GPL-3.0），
并借鉴了开源项目 **AICompare** 的部分设计思路。

- 完整 GPL-3.0 条款见 [`LICENSE`](LICENSE)，原文保留未改动；
- 修改声明与版权信息见 [`NOTICE.md`](NOTICE.md)；
- 上游作者的署名与仓库链接在「设置 → 关于」中保留。

感谢原作者与社区贡献者的开源工作。本版本仍是**自由软件**，继续以 GPL-3.0 授权。
欢迎提交 Issue 或 Pull Request，一起把这个项目做得更好。

## 本版本改了什么

| 项目 | 说明 |
|---|---|
| 品牌 | 名称、扩展标识、界面文案、图标、文字标全部更换为 Vandashot |
| 默认站点 | 移除原作者预置的自定义站点，改为 **GitHub 搜索**（可配置） |
| 关于页 | 移除原作者社媒账号，改为本项目维护者 `yangge73440` 的 GitHub 链接 |
| 文档外链 | 移除原作者飞书文档，改为项目自身 README |
| 品牌配置 | 新增 `brand.config.mjs` 单一数据源 + `scripts/apply-brand.mjs` 注入脚本，改一处全局生效 |
| 图标生成 | `scripts/make-icons.mjs` 零依赖生成 16/32/48/128 PNG |
| 文档 | 重写中文 README、隐私政策，新增 NOTICE 与二次开发指南 |

> 按维护者选择，**以下三项本版本保持上游原样**，未改动功能行为，详见 [`DEV-GUIDE.md`](DEV-GUIDE.md)：
> 默认开启的站点预热、实验模块开关残留、扩展权限范围。

## 快速开始

需要 Node.js 18+（本项目在 Node 22 下验证）。

```bash
npm install --include=dev
npm run build:store
```

`prebuild:store` 钩子会自动先执行品牌注入，产物在 `dist/`（约 82 个文件）。

然后打开 `chrome://extensions/` → 开启「开发者模式」→「加载已解压的扩展程序」→ 选择 **`dist/`**。

> `dist/` 是构建产物，不入库；改代码请编辑 `src/`，再重新构建。
> 直接使用 `npm run build`（不带 `:store`）会尝试编译上游未公开的实验模块而**报错**，
> 原因与解法见二次开发指南。

## 基本使用

1. 点击工具栏图标，或在任意网页按 **Ctrl+Q** 唤起浮层；
2. 输入问题，选择一个搜索组，进入 Compare 对比页；
3. 各站点卡片加载完成后点击发送，并排阅读回答；
4. 可选：导出 Markdown、AI 一键总结、切换布局、追加站点。

首次安装会写入默认搜索组、提示词库和默认自定义站点。

## 改成你自己的版本

所有品牌信息集中在根目录 **`brand.config.mjs`**：

```js
export const BRAND = {
  name: "Vandashot",
  version: "2.0.0",
  owner: "yangge73440",
  links: { website: "", repository: "...", profile: "...", docs: "...", social: [] },
  defaultCustomSite: { name: "GitHub 搜索", url: "https://github.com/search?q={query}", ... },
  upstream: { ... },   // GPL 要求保留，请勿删除
};
```

改完运行 `npm run brand`（或直接 `npm run build:store`）即可全局生效，脚本是幂等的。
注入范围覆盖：扩展名与描述、manifest、界面文案、右键菜单、关于页、初始预设、
文字标 SVG、四档 PNG 图标、NOTICE 与隐私政策。

详见 [`DEV-GUIDE.md`](DEV-GUIDE.md)。

## 目录结构

```
Vandashot/
├── brand.config.mjs          # 品牌唯一数据源（先改这里）
├── scripts/
│   ├── apply-brand.mjs       # 品牌注入
│   └── make-icons.mjs        # PNG 图标生成
├── src/
│   ├── manifest.json         # MV3 清单
│   ├── background/           # Service Worker、右键菜单、快捷键、站点预热
│   ├── iframe/               # 对比页 + inject + overlay + 样式（核心）
│   ├── popup/                # 工具栏弹窗
│   ├── settings/             # 设置页（21 个分区）
│   ├── config/               # 站点规则、初始预设、随机问题库、DNR 规则源
│   ├── shared/               # 国际化、AI 服务商、存储键、诊断
│   ├── icons/                # 扩展图标
│   └── _locales/             # 中英文扩展名与描述
├── build.mjs                 # esbuild 打包
├── LICENSE                   # GPL-3.0 原文（勿删）
├── NOTICE.md                 # 修改声明（勿删）
├── PRIVACY.md                # 隐私政策
├── DEV-GUIDE.md              # 二次开发指南
└── dist/                     # 构建产物（不入库）
```

## 权限与隐私

请求的权限包括 `storage`、`activeTab`/`tabs`/`windows`、`contextMenus`、`alarms`、
`declarativeNetRequest` 以及 `host_permissions: <all_urls>`。
其中 DNR 用于移除第三方站点的 CSP / X-Frame-Options 等响应头，让它们能嵌入对比页卡片；
`<all_urls>` 用于在你访问的页面注入浮层、定位输入框并支持自定义站点。

- 配置、提示词、历史、API Key 全部存在 `chrome.storage.local`；
- 搜索与 AI 总结请求由浏览器**直连**你选择的站点 / 服务商；
- 无后端服务器、无遥测、无第三方统计 SDK、无远程脚本加载（CSP 限定 `script-src 'self'`）。

完整说明见 [`PRIVACY.md`](PRIVACY.md)。

## 授权

**GNU General Public License v3.0**，见 [`LICENSE`](LICENSE)。

你可以自由使用、修改和分发；若分发本作品（含编译后的 `dist/`），
必须同时提供对应源代码、保留版权与协议声明，并继续以 GPL-3.0 授权。
修改声明见 [`NOTICE.md`](NOTICE.md)。
