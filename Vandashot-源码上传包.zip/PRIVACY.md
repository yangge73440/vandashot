# Vandashot 隐私政策

**适用版本**：Vandashot 2.0.0 及以上
**维护者**：yangge73440
**项目仓库**：https://github.com/yangge73440/Vandashot
**上游项目**：Qshot · 子弹搜索（https://github.com/30bewater/Qshot）

> 本政策由上游 Qshot · 子弹搜索 隐私政策改编，适用于本修改版。
> 上游原作者不对本修改版的行为负责。

## 一句话说明

Vandashot 是一个**纯本地运行**的浏览器扩展。它没有后端服务器，
不收集、不上传你的搜索关键词、浏览记录、页面内容或账号信息。

## 数据存在哪里

| 数据 | 存储位置 | 是否外传 |
|---|---|---|
| 搜索组、自定义站点、提示词库 | `chrome.storage.local`（本机浏览器） | 否 |
| 搜索历史（默认关闭） | `chrome.storage.local` | 否 |
| 布局、主题、快捷键等偏好 | `chrome.storage.local` | 否 |
| AI 总结用的 API Key | `chrome.storage.local`，密码框输入 | 仅发送给你自己选择的服务商 |
| 导出的 JSON / Markdown | 由你主动下载到本机 | 否 |

## 网络请求会发到哪里

1. **你选择的 AI / 搜索站点** —— 由浏览器直连，使用你自己的登录会话；
2. **你配置的 AI 总结服务商** —— 仅在启用该功能、填入自己的 API Key 后，
   由浏览器直连该服务商的 `/chat/completions` 接口；
3. **同源导出** —— 导出 ChatGPT 对话时读取其 `/backend-api/conversation/*`，
   请求发往 chatgpt.com 自身；
4. **站点预热（可关闭）** —— 默认每 5 分钟向已启用的 AI 站点发一次
   `no-cors` 请求以缩短首次加载时间，会复用你的登录 Cookie，但不读取响应内容。
   可在设置中关闭「预加载 / prewarm」。

**不会**向维护者或任何第三方统计服务器发送数据。

## 权限说明

| 权限 | 用途 |
|---|---|
| `storage` | 本地保存配置 |
| `activeTab` / `tabs` / `windows` | 打开对比页、站点标签页与弹窗 |
| `contextMenus` | 选中文字后的右键搜索入口 |
| `alarms` | 站点预热定时 |
| `declarativeNetRequest` | 调整第三方站点的 CSP / X-Frame-Options 等响应头，使其能嵌入对比页卡片 |
| `host_permissions: <all_urls>` | 在你访问的页面注入浮层、定位输入框、提取导出内容，并支持自定义站点 |
| `downloads` | 导出文件（当前商店构建版未启用） |

扩展的 Content Security Policy 限定 `script-src 'self'`，
**不会加载任何远程脚本**，也不包含第三方分析、广告或追踪 SDK。

## 关于 AI 总结

该功能默认关闭，需要你自行填写 API Key。密钥仅保存在本机，
只会出现在发往你所选择服务商的 `Authorization` 请求头中。
请勿分享含有密钥的导出 JSON。

## 修改与联系

本版本基于 GPL-3.0 项目修改，详见 `NOTICE.md`。
问题与建议请提交至：https://github.com/yangge73440/Vandashot
