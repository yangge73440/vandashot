// 自动生成，请勿手动编辑 —— 改根目录 brand.config.mjs 后运行 npm run brand
import { state, msg } from "../state.js";
import { BRAND } from "../../../config/brand.generated.js";

export function renderAboutSection() {
  const { aboutSection } = state.dom;
  aboutSection.innerHTML = "";

  const privacyCard = document.createElement("section");
  privacyCard.className = "other-settings-card about-plugin-card";
  privacyCard.innerHTML = `
    <div class="other-settings-intro about-plugin-intro">
      <strong>${msg("settings_about_privacyTitle", "隐私与数据说明")}</strong>
    </div>
    <div class="about-plugin-privacy" role="note">
      <p><strong>${msg("settings_about_openSourceLabel", "开源且免费：")}</strong>${msg("settings_about_openSourceBody", "Vandashot 是一个开源且免费插件，不会运行任何后端服务器。")}</p>
      <p><strong>${msg("settings_about_zeroDataLabel", "零数据收集：")}</strong>${msg("settings_about_zeroDataBody", "Vandashot 不会将您的搜索关键词、浏览记录或页面内容上传到开发者服务器。用于功能的配置数据仅保存在本地。")}</p>
      <p><strong>${msg("settings_about_transparencyLabel", "交互透明性：")}</strong>${msg("settings_about_transparencyBody", "插件通过 iframe 或新标签页模式打开目标网站，您与网站的登录与交互均直接发生在浏览器与目标网站之间。")}</p>
      <p><strong>基于开源项目：</strong>本作品基于 ${BRAND.upstream.name}（${BRAND.upstream.author}，${BRAND.upstream.license}）修改，保留原作者版权声明。</p>
    </div>
  `;
  aboutSection.appendChild(privacyCard);

  const linksRow = document.createElement("div");
  linksRow.className = "about-plugin-links-wrap";
  linksRow.innerHTML = `
    <div class="about-plugin-actions" aria-label="相关链接">
      <a class="about-plugin-action-btn" href="https://github.com/yangge73440/Vandashot" target="_blank" rel="noreferrer noopener">项目仓库</a>
      <a class="about-plugin-action-btn" href="https://github.com/yangge73440" target="_blank" rel="noreferrer noopener">开发者主页</a>
      <a class="about-plugin-action-btn" href="https://github.com/30bewater/Qshot" target="_blank" rel="noreferrer noopener">上游项目</a>
    </div>
  `;
  aboutSection.appendChild(linksRow);
}
