// 自动生成，请勿手动编辑 —— 改根目录 brand.config.mjs 后运行 npm run brand
export const BRAND = {
  "id": "vandashot",
  "name": "Vandashot",
  "version": "2.0.0",
  "owner": "yangge73440",
  "tagline": {
    "zh": "一次提问，并排对比多个 AI",
    "en": "Ask once, compare every AI side by side"
  },
  "description": {
    "zh": "Vandashot 让搜索更快、更全面：同时调用多个 AI / 搜索站点，并排对比回答、导出整理。",
    "en": "Vandashot makes search faster and more comprehensive by querying multiple AI/search sites side by side."
  },
  "links": {
    "website": "",
    "repository": "https://github.com/yangge73440/Vandashot",
    "profile": "https://github.com/yangge73440",
    "docs": "https://github.com/yangge73440/Vandashot#readme",
    "social": []
  },
  "defaultCustomSite": {
    "name": "GitHub 搜索",
    "url": "https://github.com/search?q={query}",
    "matchPatterns": [
      "github.com"
    ]
  },
  "upstream": {
    "name": "Qshot · 子弹搜索",
    "author": "30bewater",
    "repository": "https://github.com/30bewater/Qshot",
    "license": "GPL-3.0",
    "modifiedOn": "2026-11-07"
  }
};

if (typeof globalThis !== "undefined") {
  globalThis.__VANDASHOT_BRAND__ = BRAND;
}

export default BRAND;
